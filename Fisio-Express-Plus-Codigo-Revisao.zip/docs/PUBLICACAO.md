# Publicação exclusiva do Fisio Express Plus

Não executar antes da aprovação do proprietário. Não alterar, implantar, copiar configurações de volta ou reutilizar o projeto Cloudflare Pages `fisio-express`.

## Configuração independente

- Pasta: `/workspace/fisio-express-plus`.
- Build: `bun run build`, saída `dist-plus`.
- Projeto Cloudflare Pages proposto: `fisio-express-plus`.
- Domínio proposto: `fisio-express-plus.pages.dev`; disponibilidade ainda não verificada. Confirmar o domínio real após criar/publicar.
- Produção em projeto próprio, sem integração automática de publicação do repositório de vendas.
- Namespace KV exclusivo, binding `PLUS_AUTH_KV`. Não compartilhar KV com o site público ou ambientes de teste.
- Segredo de produção `PLUS_PASSWORD`: mínimo 12 caracteres, fornecido pelo proprietário em campo seguro, nunca em conversa, repositório ou bundle.
- Segredo `PLUS_SESSION_SECRET`: pelo menos 32 caracteres aleatórios, gerado e gravado diretamente como segredo da Cloudflare, sem imprimir o valor.
- Usuário compartilhado fixo: `admin`.

Variáveis desta entrega no ambiente de desenvolvimento: `FISIO_PLUS_PASSWORD`, `FISIO_PLUS_CLOUDFLARE_API_TOKEN`, `FISIO_PLUS_ACCOUNT_ID`. São independentes das variáveis do projeto público. O token deve pertencer à conta escolhida e permitir Cloudflare Pages Edit e Workers KV Storage Edit. O segredo de sessão será gerado de forma segura na preparação da publicação; não há valor padrão.

## Sequência após aprovação

1. Validar credenciais e conta Cloudflare. Criar somente o novo projeto Pages, com branch de produção `main`, confirmando que o projeto escolhido é `fisio-express-plus`.
2. Criar o namespace KV exclusivo e vinculá-lo a `PLUS_AUTH_KV` na configuração de produção do novo projeto. Criar outro namespace para preview caso previews sejam publicados.
3. Configurar `PLUS_PASSWORD` a partir do segredo `FISIO_PLUS_PASSWORD` e gerar/configurar `PLUS_SESSION_SECRET`, ambos como Secrets criptografados. Não utilizar variáveis VITE_ para segredos. Se houver previews, usar segredos próprios e não reutilizar contas de testes.
4. Copiar `wrangler.example.toml` para `wrangler.toml`, preencher o namespace real e revisar o nome do projeto. O arquivo não contém senhas; o `.gitignore` exclui a configuração local por prevenção.
5. Repetir build e verificações. `scripts/deploy-plus.sh --approved` tem guardas contra projeto errado e configuração incompleta. O marcador de linha de comando não substitui a aprovação real do proprietário.
6. Publicar somente `dist-plus` no projeto novo, com o Worker e `_routes.json`. Não publicar apenas os assets nem excluir o Worker. Um upload puramente estático, sem Worker e bindings, não atende à proteção solicitada.
7. Verificar o endereço público real: login anônimo, bloqueio de imagens/JS sem cookie, login, cem imagens autenticadas, PDF e logout. Conferir que o site original permanece inalterado. Só então entregar o URL público real.

## Segurança implementada

Senha validada no servidor com comparação de hashes em tempo constante. Token de sessão aleatório de 256 bits assinado com HMAC-SHA256, registro no KV e cookie `__Host-fisio-plus`, Secure, HttpOnly, SameSite=Strict, Path=/, validade de oito horas. Rotação de senha ou chave invalida sessões anteriores. Logout apaga a sessão do servidor e expira o cookie. Login e logout verificam Origin, aceitam somente os métodos previstos e não registram a senha em logs. Respostas privadas têm no-store, CSP, bloqueio de frames e noindex. Todas as rotas passam pelo Worker, sem exclusões. Sem segredos ou credenciais reais no build.

Limitação básica de dez tentativas incorretas por identificador de origem/IP em dez minutos. O identificador é derivado com HMAC; o IP não é guardado em texto. KV é eventualmente consistente, portanto não impede rajadas distribuídas com precisão atômica. Para escala comercial, considerar rate limiting na borda/contas individuais em uma fase posterior.
