# Fisio Express Plus

Aplicação independente. Não editar, publicar, copiar arquivos de volta ou alterar o projeto /workspace/fisio-express. Login é validado no Worker, com sessão em KV e cookie HttpOnly/Secure; todo o catálogo e todos os assets exigem sessão. Nunca publicar segredo no repositório ou no build. Não implantar antes da aprovação expressa do proprietário para esta versão Plus.
