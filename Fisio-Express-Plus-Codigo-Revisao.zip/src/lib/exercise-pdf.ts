import { createClientOnlyFn } from "@tanstack/react-start";
import type { Exercise } from "@/data/exercises";

export type PrescriptionItem = {
  exercise: Exercise;
  series: string;
  repetitions: string;
  duration: string;
  frequency: string;
  observation: string;
};

export type Prescription = {
  professional: string;
  patient: string;
  items: PrescriptionItem[];
};

type PdfDocument = InstanceType<(typeof import("jspdf"))["jsPDF"]>;
type TextLine = { text: string; bold: boolean; size: number; height: number };
const LEFT = 14,
  RIGHT = 196,
  BOTTOM = 278,
  TEXT_X = 57,
  TEXT_WIDTH = RIGHT - TEXT_X;

function cleanFileName(value: string) {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .toLowerCase();
}

function addHeader(doc: PdfDocument, professional: string, patient: string) {
  doc.setFillColor(18, 56, 82);
  doc.rect(0, 0, 210, 23, "F");
  doc.setFillColor(57, 168, 142);
  doc.circle(19, 11.5, 6, "F");
  doc.setDrawColor(255, 255, 255);
  doc.setLineWidth(1);
  doc.line(16, 11.5, 22, 11.5);
  doc.line(19, 8.5, 19, 14.5);
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(15);
  doc.text("Fisio Express Plus", 30, 10);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.text("ORIENTAÇÕES DE EXERCÍCIOS", 30, 17);
  doc.setTextColor(18, 56, 82);
  doc.setFontSize(9);
  let y = 31;
  const addIdentity = (text: string, bold: boolean) => {
    doc.setFont("helvetica", bold ? "bold" : "normal");
    const lines: string[] = doc.splitTextToSize(text, RIGHT - LEFT);
    doc.text(lines, LEFT, y);
    y += lines.length * 4.2 + 2;
  };
  // Stack identity fields so long names do not overlap the date or exercise content.
  addIdentity(patient ? `Paciente: ${patient}` : "Orientação personalizada", true);
  if (professional) addIdentity(`Profissional: ${professional}`, false);
  const date = new Intl.DateTimeFormat("pt-BR").format(new Date());
  addIdentity(`Data: ${date}`, false);
  return y + 2;
}

function addFooter(doc: PdfDocument, page: number) {
  doc.setDrawColor(219, 229, 232);
  doc.line(LEFT, 283, RIGHT, 283);
  doc.setTextColor(99, 115, 122);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7);
  doc.text(
    "Material personalizado pelo profissional responsável. Siga somente as orientações recebidas.",
    LEFT,
    289,
  );
  doc.text(String(page), RIGHT, 289, { align: "right" });
}

export const createExercisePdf = createClientOnlyFn(async (prescription: Prescription) => {
  if (!prescription.items.length) throw new Error("Selecione um exercício para gerar a ficha.");
  const { jsPDF } = await import("jspdf");
  const doc = new jsPDF({ unit: "mm", format: "a4", compress: true });
  doc.setProperties({
    title: "Orientações de exercícios | Fisio Express Plus",
    creator: "Fisio Express Plus",
  });
  let page = 1;
  let pageTop = addHeader(doc, prescription.professional, prescription.patient);
  let cursor = pageTop;
  const newPage = () => {
    addFooter(doc, page);
    doc.addPage();
    page += 1;
    pageTop = addHeader(doc, prescription.professional, prescription.patient);
    cursor = pageTop;
  };

  for (const [index, item] of prescription.items.entries()) {
    let imageData: string | undefined;
    if (item.exercise.image) {
      const response = await fetch(item.exercise.image);
      if (!response.ok) throw new Error("Não foi possível carregar a imagem do exercício.");
      const imageBlob = await response.blob();
      imageData = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(reader.error);
        reader.readAsDataURL(imageBlob);
      });
    }
    const lines: TextLine[] = [];
    const paragraph = (text: string, bold = false, size = 9) => {
      doc.setFont("helvetica", bold ? "bold" : "normal");
      doc.setFontSize(size);
      const wrapped: string[] = doc.splitTextToSize(text, TEXT_WIDTH);
      for (const text of wrapped) lines.push({ text, bold, size, height: size * 0.3528 * 1.25 });
      lines.push({ text: "", bold: false, size, height: 1.6 });
    };
    paragraph(`${item.exercise.region} | ${item.exercise.category}`, false, 8);
    paragraph("Como executar", true);
    item.exercise.instructions.forEach((line, step) => paragraph(`${step + 1}. ${line}`));
    if (item.exercise.equipment) paragraph(`Equipamento: ${item.exercise.equipment}`, false, 8);
    if (item.exercise.notes) paragraph(item.exercise.notes, false, 8);
    const parameters = [
      item.series && `Séries: ${item.series}`,
      item.repetitions && `Repetições: ${item.repetitions}`,
      item.duration && `Tempo: ${item.duration}`,
      item.frequency && `Frequência: ${item.frequency}`,
    ]
      .filter(Boolean)
      .join(" | ");
    paragraph(parameters || "Parâmetros conforme orientação do profissional.", true);
    if (item.observation) paragraph(`Observações: ${item.observation}`);

    const title = `${index + 1}. ${item.exercise.name}`;
    const titleLines = (continued: boolean): string[] => {
      doc.setFont("helvetica", "bold");
      doc.setFontSize(11);
      return doc.splitTextToSize(title + (continued ? " (continuação)" : ""), RIGHT - LEFT - 6);
    };
    const titleHeight = titleLines(false).length * 4.8 + 6;
    const textHeight = lines.reduce((height, line) => height + line.height, 0);
    const totalHeight = titleHeight + Math.max(imageData ? 37 : 0, textHeight) + 5;
    // Keep an ordinary exercise together; long descriptions continue without clipping.
    if (
      cursor > pageTop &&
      (totalHeight <= BOTTOM - pageTop
        ? cursor + totalHeight > BOTTOM
        : cursor + titleHeight + 37 > BOTTOM)
    )
      newPage();

    const startSection = (continued: boolean) => {
      const wrapped = titleLines(continued);
      const height = wrapped.length * 4.8 + 5;
      doc.setFillColor(234, 246, 241);
      doc.roundedRect(LEFT, cursor, RIGHT - LEFT, height, 2, 2, "F");
      doc.setTextColor(18, 56, 82);
      doc.text(wrapped, LEFT + 3, cursor + 5);
      cursor += height + 3;
      if (imageData) {
        const dimensions = doc.getImageProperties(imageData);
        const scale = Math.min(37 / dimensions.width, 37 / dimensions.height);
        const width = dimensions.width * scale,
          height = dimensions.height * scale;
        doc.addImage(
          imageData,
          dimensions.fileType,
          LEFT + (37 - width) / 2,
          cursor,
          width,
          height,
          undefined,
          "FAST",
        );
      }
      return cursor + (imageData ? 37 : 0);
    };
    let imageBottom = startSection(false);
    for (const line of lines) {
      if (cursor + line.height > BOTTOM) {
        newPage();
        imageBottom = startSection(true);
      }
      doc.setFont("helvetica", line.bold ? "bold" : "normal");
      doc.setFontSize(line.size);
      doc.setTextColor(line.bold ? 18 : 53, line.bold ? 56 : 65, line.bold ? 82 : 70);
      // Use a baseline inside the measured line box, leaving room for descenders.
      if (line.text) doc.text(line.text, TEXT_X, cursor + line.height * 0.78);
      cursor += line.height;
    }
    cursor = Math.max(cursor, imageBottom) + 6;
  }
  addFooter(doc, page);
  const suffix = cleanFileName(prescription.patient || "exercicios");
  return { blob: doc.output("blob"), fileName: `orientacoes-${suffix || "exercicios"}.pdf` };
});

export function downloadBlob(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1_000);
}
