import { createFileRoute } from "@tanstack/react-router";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  ChevronDown,
  ChevronUp,
  ClipboardList,
  Download,
  ExternalLink,
  FileText,
  LoaderCircle,
  Menu,
  Plus,
  Search,
  Share2,
  ShieldCheck,
  Trash2,
  X,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";

import { CustomExerciseDialog } from "@/components/custom-exercise-dialog";
import {
  MAX_BACKUP_BYTES,
  parseBackup,
  readCustomExercises,
  writeCustomExercises,
} from "@/lib/custom-exercises";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { ExerciseIllustration } from "@/components/exercise-illustration";
import {
  regions,
  exercises as baseExercises,
  matchesExercise,
  type Exercise,
} from "@/data/exercises";
import { createExercisePdf, downloadBlob, type PrescriptionItem } from "@/lib/exercise-pdf";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Fisio Express Plus | Orientações de exercícios" },
      {
        name: "description",
        content:
          "Prepare orientações de exercícios domiciliares: selecione os movimentos, defina os parâmetros e compartilhe com cada paciente.",
      },
      { property: "og:title", content: "Fisio Express Plus" },
      {
        property: "og:description",
        content:
          "Sua prescrição de exercícios, organizada em uma orientação ilustrada para o paciente.",
      },
    ],
  }),
  component: Index,
});

type Stage = "library" | "customize" | "preview";
type PrescriptionFields = Omit<PrescriptionItem, "exercise">;

const emptyFields: PrescriptionFields = {
  series: "",
  repetitions: "",
  duration: "",
  frequency: "",
  observation: "",
};

export function Index() {
  const generationLock = useRef(false);
  const downloadedBlob = useRef<Blob | null>(null);
  const [stage, setStage] = useState<Stage>("library");
  const [search, setSearch] = useState("");
  const [libraryStarted, setLibraryStarted] = useState(false);
  const [regionPickerOpen, setRegionPickerOpen] = useState(true);
  const [searchOpen, setSearchOpen] = useState(false);
  const [visibleCount, setVisibleCount] = useState(4);
  const changeRegion = (region: string) => {
    setActiveCategory(region);
    setLibraryStarted(true);
    setRegionPickerOpen(false);
    setVisibleCount(4);
  };
  const [activeCategory, setActiveCategory] = useState("");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [prescriptions, setPrescriptions] = useState<Record<string, PrescriptionFields>>({});
  const [professional, setProfessional] = useState("");
  const [patient, setPatient] = useState("");
  const [pdfBlob, setPdfBlob] = useState<Blob | null>(null);
  const [pdfUrl, setPdfUrl] = useState("");
  const [fileName, setFileName] = useState("orientacoes-exercicios.pdf");
  const [isGenerating, setIsGenerating] = useState(false);
  const [notice, setNotice] = useState("");
  const [mobileMenu, setMobileMenu] = useState(false);
  const libraryRef = useRef<HTMLElement>(null);
  const [customExercises, setCustomExercises] = useState<Exercise[]>([]);
  const [customOnly, setCustomOnly] = useState(false);
  const [editor, setEditor] = useState<Exercise | null | undefined>(undefined);
  const [deleting, setDeleting] = useState<Exercise | null>(null);
  const [storageReady, setStorageReady] = useState(false);
  const [storageError, setStorageError] = useState("");
  const [storageBusy, setStorageBusy] = useState(false);
  const importRef = useRef<HTMLInputElement>(null);
  const exercises = useMemo(() => [...baseExercises, ...customExercises], [customExercises]);
  useEffect(() => {
    let active = true;
    readCustomExercises()
      .then((items) => {
        if (active) {
          setCustomExercises(items);
          setStorageReady(true);
        }
      })
      .catch(() => {
        if (active)
          setStorageError(
            "O armazenamento deste navegador está indisponível. Seus exercícios existentes não foram alterados. Verifique as permissões do navegador e recarregue a página.",
          );
      });
    return () => {
      active = false;
    };
  }, []);
  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(""), 6000);
    return () => window.clearTimeout(timer);
  }, [notice]);
  const saveExercise = async (exercise: Exercise) => {
    try {
      await writeCustomExercises([exercise]);
    } catch {
      throw new Error(
        "Não foi possível salvar no navegador. Verifique o espaço disponível e tente novamente.",
      );
    }
    setCustomExercises((items) => [...items.filter((item) => item.id !== exercise.id), exercise]);
    if (
      stage === "customize" ||
      (stage === "library" && !customExercises.some((item) => item.id === exercise.id))
    ) {
      addExercise(exercise);
      setNotice("Exercício próprio salvo e incluído na sua ficha.");
      return;
    }
    setCustomOnly(true);
    setSearch("");
    setVisibleCount(4);
    setActiveCategory("");
    setNotice("Exercício salvo. Você já pode adicioná-lo à ficha.");
  };
  const exportExercises = () => {
    downloadBlob(
      new Blob(
        [
          JSON.stringify(
            {
              format: "fisio-express-plus-exercises",
              version: 1,
              exportedAt: new Date().toISOString(),
              exercises: customExercises,
            },
            null,
            2,
          ),
        ],
        { type: "application/json" },
      ),
      "fisio-express-plus-meus-exercicios.json",
    );
  };
  const importExercises = async (file: File) => {
    setStorageBusy(true);
    try {
      if (file.size > MAX_BACKUP_BYTES) throw new Error("O backup deve ter até 25 MB.");
      const incoming = parseBackup(await file.text());
      // Preserve current records, including edits made after an earlier backup.
      const ids = new Set(customExercises.map((item) => item.id));
      const additions = incoming.filter((item) => !ids.has(item.id));
      await writeCustomExercises(additions);
      setCustomExercises((items) => [...items, ...additions]);
      setCustomOnly(true);
      setSearch("");
      setVisibleCount(4);
      setActiveCategory("");
      setNotice(
        `${additions.length} exercício(s) importado(s). Itens já existentes foram preservados.`,
      );
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "Não foi possível importar o backup.");
    } finally {
      setStorageBusy(false);
    }
  };

  const selectedExercises = useMemo(
    () =>
      selectedIds.map((id) => exercises.find((exercise) => exercise.id === id)!).filter(Boolean),
    [selectedIds, exercises],
  );

  const visibleExercises = useMemo(
    () =>
      (customOnly ? customExercises : baseExercises).filter(
        (exercise) =>
          (!activeCategory || exercise.region === activeCategory) &&
          matchesExercise(exercise, search),
      ),
    [activeCategory, search, customOnly, customExercises],
  );
  const displayedExercises = visibleExercises.slice(0, visibleCount);
  const showExercises = libraryStarted || customOnly;
  const regionFilters = customOnly
    ? [...new Set(customExercises.map((exercise) => exercise.region))]
    : regions.filter((region) => region !== "Outro");

  useEffect(() => {
    return () => {
      if (pdfUrl) URL.revokeObjectURL(pdfUrl);
    };
  }, [pdfUrl]);

  const addExercise = (exercise: Exercise) => {
    setSelectedIds((current) =>
      current.includes(exercise.id) ? current : [...current, exercise.id],
    );
    setPrescriptions((current) => ({
      ...current,
      [exercise.id]: current[exercise.id] ?? { ...emptyFields },
    }));
    setNotice(`${exercise.name} adicionado à ficha.`);
  };

  const removeExercise = (id: string) => {
    setSelectedIds((current) => current.filter((item) => item !== id));
  };

  const moveExercise = (index: number, direction: -1 | 1) => {
    setSelectedIds((current) => {
      const target = index + direction;
      if (target < 0 || target >= current.length) return current;
      const next = [...current];
      [next[index], next[target]] = [next[target]!, next[index]!];
      return next;
    });
  };

  const updatePrescription = (id: string, field: keyof PrescriptionFields, value: string) => {
    setPrescriptions((current) => ({
      ...current,
      [id]: { ...(current[id] ?? emptyFields), [field]: value },
    }));
  };

  const startCustomization = () => {
    if (!selectedIds.length) return;
    setMobileMenu(false);
    setNotice("");
    setStage("customize");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const generatePdf = async () => {
    if (generationLock.current || !selectedExercises.length) return;
    generationLock.current = true;
    setIsGenerating(true);
    setNotice("");
    try {
      const result = await createExercisePdf({
        professional,
        patient,
        items: selectedExercises.map((exercise) => ({
          exercise,
          ...(prescriptions[exercise.id] ?? emptyFields),
        })),
      });
      if (pdfUrl) URL.revokeObjectURL(pdfUrl);
      const nextUrl = URL.createObjectURL(result.blob);

      setPdfBlob(result.blob);
      setPdfUrl(nextUrl);
      setFileName(result.fileName);
      setStage("preview");
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch {
      setNotice("Não foi possível gerar a ficha. Tente novamente.");
    } finally {
      generationLock.current = false;
      setIsGenerating(false);
    }
  };

  const downloadPdf = () => {
    if (!pdfBlob) return;
    downloadBlob(pdfBlob, fileName);
    if (downloadedBlob.current !== pdfBlob) {
      downloadedBlob.current = pdfBlob;
    }
  };

  const sharePdf = async () => {
    if (!pdfBlob) return;
    const file = new File([pdfBlob], fileName, { type: "application/pdf" });
    const message = "Olá! Segue sua ficha de orientações de exercícios.";
    if (navigator.share && (!navigator.canShare || navigator.canShare({ files: [file] }))) {
      try {
        await navigator.share({
          title: "Orientações de exercícios",
          text: message,
          files: [file],
        });
        setNotice(
          "PDF entregue ao compartilhamento do aparelho. Confirme o envio no aplicativo escolhido.",
        );
        return;
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") return;
      }
    }
    downloadPdf();
    setNotice("O PDF foi baixado. Anexe-o ao WhatsApp ou a um e-mail para compartilhar.");
  };

  const goToLibrary = () => {
    setMobileMenu(false);
    setStage("library");
    window.setTimeout(() => libraryRef.current?.scrollIntoView({ behavior: "smooth" }), 30);
  };

  return (
    <div
      className={`min-h-screen bg-background text-foreground ${stage === "library" && selectedIds.length ? "pb-36 xl:pb-0" : ""}`}
    >
      <header className="sticky top-0 z-40 border-b border-border/80 bg-white/95 backdrop-blur">
        <div className="mx-auto flex h-18 w-full max-w-[88rem] items-center justify-between gap-2 px-3 sm:gap-4 sm:px-5 md:px-8">
          <button
            type="button"
            onClick={() => {
              setStage("library");
              setMobileMenu(false);
              window.scrollTo({ top: 0 });
            }}
            className="flex items-center gap-2 text-left sm:gap-3"
          >
            <span className="grid size-8 shrink-0 place-items-center rounded-xl bg-primary text-white shadow-sm sm:size-10">
              <span className="relative block size-5">
                <span className="absolute left-2 top-0 h-5 w-1 rounded-full bg-white" />
                <span className="absolute left-0 top-2 h-1 w-5 rounded-full bg-white" />
              </span>
            </span>
            <span>
              <span className="block whitespace-nowrap text-sm font-bold tracking-tight sm:text-lg">
                Fisio Express Plus
              </span>
              <span className="hidden text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground sm:block">
                Prescrição simplificada
              </span>
            </span>
          </button>

          <p className="ml-auto hidden text-sm font-semibold text-slate-600 md:block">
            {`Etapa ${stage === "library" ? 1 : stage === "customize" ? 2 : 3} de 3`}
          </p>
          <form action="/auth/logout" method="post" className="ml-auto md:ml-0">
            <button
              type="submit"
              className="min-h-11 rounded-xl border border-border px-2 py-2 text-xs font-semibold text-primary sm:px-3 sm:text-sm"
            >
              Sair
            </button>
          </form>
          <button
            type="button"
            aria-label="Abrir menu"
            className="rounded-lg border border-border p-2 md:hidden"
            onClick={() => setMobileMenu((open) => !open)}
          >
            {mobileMenu ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
        {mobileMenu && (
          <div className="border-t border-border bg-white px-5 py-4 md:hidden">
            <button
              type="button"
              onClick={goToLibrary}
              className="block w-full py-2 text-left font-semibold"
            >
              Biblioteca
            </button>
            <button
              type="button"
              onClick={startCustomization}
              disabled={!selectedIds.length}
              className="block w-full py-2 text-left font-semibold"
            >
              Minha ficha ({selectedIds.length})
            </button>
          </div>
        )}
      </header>

      {stage === "library" && (
        <>
          <main
            id="biblioteca"
            ref={libraryRef}
            className="container-app scroll-mt-24 py-6 lg:py-12"
          >
            <div className="mb-5 flex flex-col justify-between gap-4 md:flex-row md:items-end">
              <div>
                <p className="eyebrow">Etapa 1 de 3</p>
                <h1 className="mt-2 text-2xl font-bold tracking-tight text-primary md:text-3xl">
                  {customOnly
                    ? "Escolha seus exercícios próprios"
                    : regionPickerOpen
                      ? "Qual região do corpo você deseja trabalhar?"
                      : "Escolha seus exercícios"}
                </h1>
                <p className="mt-3 text-base text-slate-600">
                  {regionPickerOpen && !customOnly
                    ? "Escolha uma região para começar."
                    : "Selecione os exercícios que você deseja orientar ao seu paciente."}
                </p>
              </div>
            </div>

            {regionPickerOpen ? (
              <div
                className="mb-6 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4"
                aria-label="Regiões do corpo"
              >
                <button
                  type="button"
                  aria-pressed={libraryStarted && !activeCategory}
                  onClick={() => changeRegion("")}
                  className={`min-h-12 rounded-xl border px-3 py-3 text-sm font-semibold ${libraryStarted && !activeCategory ? "border-primary bg-primary text-white" : "border-border bg-white text-slate-600"}`}
                >
                  Todas as regiões
                </button>
                {regionFilters.map((region) => (
                  <button
                    key={region}
                    type="button"
                    aria-pressed={activeCategory === region}
                    onClick={() => changeRegion(region)}
                    className={`min-h-12 rounded-xl border px-3 py-3 text-sm font-semibold transition ${activeCategory === region ? "border-primary bg-primary text-white shadow-sm" : "border-border bg-white text-slate-600 hover:border-green hover:text-primary"}`}
                  >
                    {region}
                  </button>
                ))}
              </div>
            ) : (
              <div className="mb-5 flex flex-wrap items-center gap-3">
                <span className="rounded-full bg-mint px-3 py-2 text-sm font-bold text-primary">
                  {customOnly ? "Meus exercícios" : activeCategory || "Todas as regiões"}
                </span>
                <button
                  type="button"
                  onClick={() => setRegionPickerOpen(true)}
                  className="min-h-11 text-sm font-semibold text-green-dark underline"
                >
                  Trocar ou adicionar região
                </button>
              </div>
            )}
            <div className="mb-5 flex flex-wrap gap-x-5 gap-y-2 text-sm">
              <button
                type="button"
                onClick={() => {
                  setSearchOpen(!searchOpen);
                  setLibraryStarted(true);
                  setRegionPickerOpen(false);
                }}
                aria-expanded={searchOpen}
                aria-controls="library-search"
                className="inline-flex min-h-11 items-center gap-2 font-semibold text-green-dark underline underline-offset-4"
              >
                <Search className="size-4" />
                Buscar por nome
              </button>
              <button
                type="button"
                aria-pressed={customOnly}
                onClick={() => {
                  setCustomOnly(!customOnly);
                  setRegionPickerOpen(false);
                  setActiveCategory("");
                  setSearch("");
                  setLibraryStarted(true);
                  setVisibleCount(4);
                }}
                className="min-h-11 font-semibold text-slate-600 underline underline-offset-4"
              >
                {customOnly ? "Voltar à biblioteca" : "Meus exercícios"}
              </button>
            </div>
            {customOnly && (
              <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
                <h3 className="font-bold text-primary">Meus exercícios</h3>
                <button
                  type="button"
                  disabled={!storageReady || storageBusy}
                  onClick={() => setEditor(null)}
                  className="inline-flex min-h-11 items-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-white disabled:opacity-50"
                >
                  <Plus className="size-4" />
                  Novo exercício
                </button>
              </div>
            )}
            {storageError && (
              <p role="alert" className="mb-5 rounded-lg bg-red-50 p-4 text-sm text-red-800">
                {storageError}
              </p>
            )}
            {customOnly && (
              <div className="mb-6 flex flex-wrap items-center justify-between gap-3 rounded-xl bg-mint p-4">
                <p className="max-w-xl text-xs leading-relaxed text-primary">
                  Seus exercícios ficam neste navegador. Exporte um backup antes de trocar de
                  aparelho ou limpar os dados. O backup não inclui informações de pacientes.
                </p>
                <div className="flex flex-wrap gap-3">
                  <button
                    type="button"
                    onClick={exportExercises}
                    disabled={!storageReady || !customExercises.length || storageBusy}
                    className="text-sm font-bold text-primary underline disabled:opacity-40"
                  >
                    Exportar backup
                  </button>
                  <button
                    type="button"
                    onClick={() => importRef.current?.click()}
                    disabled={!storageReady || storageBusy}
                    className="text-sm font-bold text-primary underline disabled:opacity-40"
                  >
                    {storageBusy ? "Importando…" : "Importar backup"}
                  </button>
                </div>
              </div>
            )}
            <input
              ref={importRef}
              type="file"
              accept="application/json,.json"
              className="hidden"
              aria-label="Arquivo de backup"
              onChange={(event) => {
                const file = event.target.files?.[0];
                if (file) void importExercises(file);
                event.target.value = "";
              }}
            />
            <div id="library-search" hidden={!searchOpen && !customOnly}>
              <label className="mb-5 block">
                <span className="mb-2 block text-sm font-bold text-primary">
                  Busca geral nos exercícios disponíveis
                </span>
                <span className="relative block">
                  <Search className="absolute left-4 top-1/2 size-5 -translate-y-1/2 text-green-dark" />
                  <input
                    value={search}
                    onChange={(event) => {
                      setSearch(event.target.value);
                      setVisibleCount(4);
                      setLibraryStarted(true);
                    }}
                    placeholder="Busque por nome, região ou equipamento"
                    className="h-14 w-full rounded-xl border border-slate-200 bg-white pl-12 pr-4 text-base outline-none focus:border-green"
                  />
                </span>
              </label>
              <p className="mb-4 text-xs text-slate-600">
                {customOnly
                  ? "Busca nos seus exercícios próprios."
                  : "Busca na prévia gratuita: três exercícios por região."}{" "}
                A busca considera todos os resultados disponíveis, inclusive os que ainda não
                apareceram na lista. Escolha Todas as regiões para ampliar o filtro.
              </p>
            </div>

            {!showExercises && (
              <p className="rounded-xl bg-mint p-4 text-sm leading-relaxed text-primary">
                Você pode combinar exercícios de diferentes regiões na mesma ficha.
              </p>
            )}
            {selectedIds.length > 0 && (
              <p
                role="status"
                className="mb-5 hidden rounded-xl bg-mint p-4 text-sm text-primary xl:block"
              >
                <strong>
                  {selectedIds.length}{" "}
                  {selectedIds.length === 1 ? "exercício adicionado" : "exercícios adicionados"} à
                  sua ficha.
                </strong>{" "}
                Você pode escolher mais exercícios ou continuar.
              </p>
            )}
            {showExercises && (
              <div className="grid gap-8 xl:grid-cols-[minmax(0,1fr)_330px]">
                <section aria-label="Exercícios disponíveis">
                  {(customOnly || !!search || !activeCategory) && (
                    <div className="mb-5 flex items-center justify-between">
                      <div>
                        <p className="font-semibold text-primary">
                          {customOnly ? "Seus exercícios" : activeCategory || "Todas as regiões"}
                        </p>
                        {!customOnly && (
                          <p className="mt-1 text-xs text-slate-500">
                            Explore os 100 exercícios da biblioteca.
                          </p>
                        )}
                      </div>
                      {search && (
                        <button
                          type="button"
                          onClick={() => {
                            setSearch("");
                            setVisibleCount(4);
                          }}
                          className="text-sm font-semibold text-green hover:underline"
                        >
                          Limpar busca
                        </button>
                      )}
                    </div>
                  )}
                  {visibleExercises.length ? (
                    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-2 2xl:grid-cols-3">
                      {displayedExercises.map((exercise) => {
                        const selected = selectedIds.includes(exercise.id);
                        return (
                          <article
                            key={exercise.id}
                            className="group grid grid-cols-[88px_minmax(0,1fr)] overflow-hidden rounded-2xl border border-border bg-white shadow-soft transition hover:border-green/40 sm:flex sm:flex-col"
                          >
                            <div className="relative p-2 sm:p-3 sm:pb-0">
                              <ExerciseIllustration
                                image={exercise.image}
                                alt={exercise.name}
                                className="aspect-square w-full rounded-xl sm:aspect-[5/3]"
                              />
                            </div>
                            <div className="flex min-w-0 flex-1 flex-col p-3 sm:p-5">
                              <div className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.11em] text-green">
                                {exercise.region}
                                <span className="size-1 rounded-full bg-slate-300" />
                                {exercise.category}
                              </div>
                              <h3 className="mt-2 text-base font-bold leading-snug text-primary sm:text-lg">
                                {exercise.name}
                              </h3>
                              <p className="mt-2 line-clamp-2 text-xs leading-relaxed text-slate-500 sm:line-clamp-none sm:text-sm">
                                {exercise.summary}
                              </p>
                              <details className="mt-2 text-xs leading-relaxed text-slate-600 sm:hidden">
                                <summary className="cursor-pointer py-1 font-semibold text-green-dark">
                                  Ver descrição completa
                                </summary>
                                <p className="mt-2">{exercise.summary}</p>
                              </details>
                              {exercise.custom && (
                                <div className="mt-4 flex gap-4 text-xs font-semibold">
                                  <button
                                    type="button"
                                    onClick={() => setEditor(exercise)}
                                    className="text-green hover:underline"
                                    aria-label={`Editar ${exercise.name}`}
                                  >
                                    Editar
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setDeleting(exercise)}
                                    className="text-red-700 hover:underline"
                                    aria-label={`Excluir ${exercise.name}`}
                                  >
                                    Excluir
                                  </button>
                                </div>
                              )}
                              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-border pt-3 sm:mt-5">
                                <span className="text-xs text-slate-400">{exercise.equipment}</span>
                                <button
                                  type="button"
                                  onClick={() =>
                                    selected ? removeExercise(exercise.id) : addExercise(exercise)
                                  }
                                  className={`inline-flex min-h-11 items-center justify-center gap-2 rounded-lg px-3.5 py-2 text-xs font-bold transition ${
                                    selected
                                      ? "bg-mint text-primary"
                                      : "bg-primary text-white hover:bg-primary-light"
                                  }`}
                                >
                                  {selected ? (
                                    <Check className="size-4" />
                                  ) : (
                                    <Plus className="size-4" />
                                  )}
                                  {selected ? "Adicionado" : "Adicionar à ficha"}
                                </button>
                              </div>
                            </div>
                          </article>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="rounded-2xl border border-dashed border-slate-300 bg-white px-6 py-16 text-center">
                      <Search className="mx-auto size-8 text-slate-300" />
                      <h3 className="mt-4 font-bold text-primary">Nenhum exercício encontrado</h3>
                      <p className="mt-2 text-sm text-slate-500">
                        {activeCategory
                          ? `A busca está filtrada em ${activeCategory}. Escolha Todas as regiões para ampliar os resultados.`
                          : "Tente outro nome, região ou equipamento. A busca considera somente os exercícios disponíveis nesta área."}
                      </p>
                      <button
                        type="button"
                        onClick={() => {
                          setSearch("");
                          changeRegion("");
                        }}
                        className="mt-4 min-h-11 font-bold text-green-dark underline"
                      >
                        Limpar busca e filtros
                      </button>
                    </div>
                  )}
                  {visibleExercises.length > displayedExercises.length && (
                    <div className="mt-5 text-center">
                      <button
                        type="button"
                        onClick={() => setVisibleCount((count) => count + 4)}
                        className="min-h-11 rounded-xl border border-green px-5 py-3 text-sm font-bold text-green-dark"
                      >
                        Ver mais exercícios
                      </button>
                      <p className="mt-2 text-xs text-slate-500">
                        Sua seleção está preservada enquanto você explora os exercícios.
                      </p>
                    </div>
                  )}
                  {!customOnly && (
                    <div className="mt-6 rounded-2xl border border-border bg-mint/50 p-5">
                      <h3 className="font-bold text-primary">
                        Não encontrou o exercício que costuma utilizar?
                      </h3>
                      <p className="mt-2 max-w-xl text-sm leading-relaxed text-slate-600">
                        Adicione seu próprio exercício, com imagem e orientações, e utilize-o nas
                        fichas dos seus pacientes.
                      </p>
                      <button
                        type="button"
                        onClick={() => setEditor(null)}
                        disabled={!storageReady || storageBusy}
                        className="mt-4 inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-xl border border-primary/30 bg-white px-4 py-3 text-sm font-bold text-primary transition hover:bg-mint active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50 sm:w-auto"
                      >
                        <Plus aria-hidden="true" className="size-4" /> Adicionar meu exercício
                      </button>
                      <p className="mt-3 text-xs leading-relaxed text-slate-500">
                        Ao salvar, ele entra nesta ficha e fica guardado neste navegador. Sem
                        sincronização entre aparelhos; use o backup em Meus exercícios.
                      </p>
                    </div>
                  )}
                  {!!selectedIds.length && (
                    <p className="mt-5 text-sm font-semibold text-primary">
                      Sua seleção está pronta. Continue para adaptar as orientações.
                    </p>
                  )}
                </section>

                <SelectionPanel
                  selectedExercises={selectedExercises}
                  onRemove={removeExercise}
                  onMove={moveExercise}
                  onContinue={startCustomization}
                />
              </div>
            )}
          </main>
        </>
      )}

      {stage === "customize" && (
        <CustomizationView
          professional={professional}
          patient={patient}
          selectedExercises={selectedExercises}
          prescriptions={prescriptions}
          isGenerating={isGenerating}
          onProfessional={setProfessional}
          onPatient={setPatient}
          onUpdate={updatePrescription}
          onBack={goToLibrary}
          onNewExercise={() => setEditor(null)}
          canCreate={storageReady && !storageBusy}
          onGenerate={generatePdf}
        />
      )}

      {stage === "preview" && pdfBlob && (
        <PreviewView
          pdfUrl={pdfUrl}
          fileName={fileName}
          pdfBlob={pdfBlob}
          selectedCount={selectedIds.length}
          notice={notice}
          onBack={() => setStage("customize")}
          onDownload={downloadPdf}
          onShare={sharePdf}
        />
      )}

      {editor !== undefined && (
        <CustomExerciseDialog
          key={editor?.id ?? "new"}
          initial={editor}
          onClose={() => setEditor(undefined)}
          onSave={saveExercise}
        />
      )}
      <Dialog
        open={!!deleting}
        onOpenChange={(open) => {
          if (!open && !storageBusy) setDeleting(null);
        }}
      >
        <DialogContent className="w-[calc(100%-24px)] rounded-2xl bg-white">
          <DialogTitle>Excluir exercício?</DialogTitle>
          <DialogDescription>
            O exercício “{deleting?.name}” será removido deste navegador e da ficha atual. Exporte
            um backup se desejar guardar uma cópia.
          </DialogDescription>
          <div className="flex justify-end gap-3">
            <button
              type="button"
              disabled={storageBusy}
              onClick={() => setDeleting(null)}
              className="rounded-lg border border-border px-4 py-2"
            >
              Cancelar
            </button>
            <button
              type="button"
              disabled={storageBusy}
              onClick={async () => {
                if (!deleting) return;
                setStorageBusy(true);
                try {
                  await writeCustomExercises([], deleting.id);
                  setCustomExercises((items) => items.filter((item) => item.id !== deleting.id));
                  removeExercise(deleting.id);
                  setDeleting(null);
                  setNotice("Exercício excluído.");
                } catch {
                  setNotice("Não foi possível excluir. Tente novamente.");
                } finally {
                  setStorageBusy(false);
                }
              }}
              className="rounded-lg bg-red-700 px-4 py-2 text-white"
            >
              {storageBusy ? "Excluindo…" : "Excluir exercício"}
            </button>
          </div>
        </DialogContent>
      </Dialog>
      {notice &&
        stage !== "preview" &&
        !(stage === "library" && notice.endsWith("adicionado à ficha.")) && (
          <div
            role="status"
            className="fixed bottom-36 left-1/2 z-[60] w-[calc(100%-32px)] max-w-lg -translate-x-1/2 rounded-xl bg-primary px-4 py-3 text-sm font-semibold text-white shadow-card md:bottom-6"
          >
            {notice}
          </div>
        )}

      {stage === "library" && selectedIds.length > 0 && (
        <div className="fixed inset-x-3 bottom-3 z-40 rounded-2xl bg-primary p-3 text-white shadow-card xl:hidden">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <div className="min-w-0 pl-1" role="status">
              <p className="text-sm font-bold">
                {selectedIds.length}{" "}
                {selectedIds.length === 1 ? "exercício adicionado" : "exercícios adicionados"} à sua
                ficha.
              </p>
              <p className="mt-1 text-xs text-white/75">
                Você pode escolher mais exercícios ou continuar.
              </p>
            </div>
            <button
              type="button"
              onClick={startCustomization}
              className="action-primary inline-flex min-h-12 shrink-0 items-center justify-center gap-2 rounded-xl bg-green px-4 py-3 text-sm font-bold text-white"
            >
              Continuar para personalizar <ArrowRight className="size-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function SelectionPanel({
  selectedExercises,
  onRemove,
  onMove,
  onContinue,
}: {
  selectedExercises: Exercise[];
  onRemove: (id: string) => void;
  onMove: (index: number, direction: -1 | 1) => void;
  onContinue: () => void;
}) {
  return (
    <aside className="sticky top-24 hidden h-fit overflow-hidden rounded-2xl border border-border bg-white shadow-card xl:block">
      <div className="flex items-center justify-between border-b border-border bg-primary px-5 py-4 text-white">
        <div>
          <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-white/60">
            Minha ficha
          </p>
          <p className="mt-1 font-bold">
            {selectedExercises.length} {selectedExercises.length === 1 ? "exercício" : "exercícios"}
          </p>
        </div>
        <ClipboardList className="size-6 text-green-light" />
      </div>

      {selectedExercises.length ? (
        <div>
          <div className="max-h-[430px] divide-y divide-border overflow-y-auto px-4">
            {selectedExercises.map((exercise, index) => (
              <div key={exercise.id} className="flex items-center gap-3 py-3.5">
                <span className="grid size-7 shrink-0 place-items-center rounded-lg bg-mint text-xs font-bold text-primary">
                  {index + 1}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-bold text-primary">{exercise.name}</p>
                  <p className="text-xs text-slate-400">{exercise.region}</p>
                </div>
                <div className="flex items-center">
                  <button
                    type="button"
                    aria-label="Mover para cima"
                    disabled={index === 0}
                    onClick={() => onMove(index, -1)}
                    className="grid size-11 place-items-center text-slate-500 disabled:opacity-25"
                  >
                    <ChevronUp className="size-3.5" />
                  </button>
                  <button
                    type="button"
                    aria-label="Mover para baixo"
                    disabled={index === selectedExercises.length - 1}
                    onClick={() => onMove(index, 1)}
                    className="grid size-11 place-items-center text-slate-500 disabled:opacity-25"
                  >
                    <ChevronDown className="size-3.5" />
                  </button>
                  <button
                    type="button"
                    aria-label="Remover exercício"
                    onClick={() => onRemove(exercise.id)}
                    className="ml-1 grid size-11 place-items-center text-slate-500 hover:text-red-600"
                  >
                    <Trash2 className="size-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
          <div className="border-t border-border p-4">
            <button
              type="button"
              onClick={onContinue}
              className="action-primary flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-green px-4 py-3.5 text-sm font-bold text-white shadow-sm hover:bg-green-dark"
            >
              Continuar para personalizar <ArrowRight className="size-4" />
            </button>
            <p className="mt-3 text-center text-[11px] leading-relaxed text-slate-400">
              Você poderá ajustar séries, repetições e observações.
            </p>
          </div>
        </div>
      ) : (
        <div className="px-6 py-12 text-center">
          <ClipboardList className="mx-auto size-8 text-slate-300" />
          <p className="mt-4 text-sm font-bold text-primary">Escolha os exercícios para começar</p>
          <p className="mt-2 text-xs leading-relaxed text-slate-400">
            Adicione exercícios da biblioteca para começar.
          </p>
        </div>
      )}
    </aside>
  );
}

function CustomizationView({
  professional,
  patient,
  selectedExercises,
  prescriptions,
  isGenerating,
  onProfessional,
  onPatient,
  onUpdate,
  onBack,
  onGenerate,
  onNewExercise,
  canCreate,
}: {
  professional: string;
  patient: string;
  selectedExercises: Exercise[];
  prescriptions: Record<string, PrescriptionFields>;
  isGenerating: boolean;
  onProfessional: (value: string) => void;
  onPatient: (value: string) => void;
  onUpdate: (id: string, field: keyof PrescriptionFields, value: string) => void;
  onBack: () => void;
  onGenerate: () => void;
  onNewExercise: () => void;
  canCreate: boolean;
}) {
  return (
    <main className="container-narrow py-10 md:py-14">
      <button
        type="button"
        onClick={onBack}
        className="inline-flex items-center gap-2 text-sm font-bold text-slate-500 hover:text-primary"
      >
        <ArrowLeft className="size-4" /> Voltar à biblioteca
      </button>
      <div className="mt-8 flex flex-col justify-between gap-4 border-b border-border pb-8 md:flex-row md:items-end">
        <div>
          <p className="eyebrow">Etapa 2 de 3</p>
          <h1 className="mt-2 text-3xl font-bold tracking-tight text-primary md:text-4xl">
            Agora personalize a orientação do seu paciente.
          </h1>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-slate-500">
            Preencha apenas o que fizer sentido para sua avaliação. Nenhum dado é enviado ou salvo
            em servidor.
          </p>
        </div>
        <div className="flex items-center gap-2 rounded-xl bg-mint px-4 py-3 text-xs font-semibold text-primary">
          <ShieldCheck className="size-5 text-green" /> Dados somente nesta sessão
        </div>
      </div>

      <section className="mt-8 rounded-2xl border border-border bg-white p-5 shadow-soft md:p-7">
        <div className="mb-5 flex items-center gap-3">
          <span className="grid size-8 place-items-center rounded-lg bg-primary text-sm font-bold text-white">
            1
          </span>
          <div>
            <h2 className="font-bold text-primary">Identificação</h2>
            <p className="text-xs text-slate-400">Campos opcionais exibidos no PDF</p>
          </div>
        </div>
        <div className="grid gap-5 md:grid-cols-2">
          <TextField
            label="Nome do profissional"
            value={professional}
            onChange={onProfessional}
            placeholder="Ex.: Dra. Marina Silva — CREFITO 000000-F"
          />
          <TextField
            label="Identificação do paciente"
            value={patient}
            onChange={onPatient}
            placeholder="Ex.: Ana M. ou código interno"
          />
        </div>
      </section>

      <div className="mt-8 flex items-center gap-3">
        <span className="grid size-8 place-items-center rounded-lg bg-primary text-sm font-bold text-white">
          2
        </span>
        <div>
          <h2 className="font-bold text-primary">Exercícios e orientações</h2>
          <p className="text-xs text-slate-400">Ajuste cada item conforme sua avaliação</p>
        </div>
      </div>

      <div className="mt-5 space-y-5">
        {selectedExercises.map((exercise, index) => {
          const values = prescriptions[exercise.id] ?? emptyFields;
          return (
            <article
              key={exercise.id}
              className="overflow-hidden rounded-2xl border border-border bg-white shadow-soft"
            >
              <div className="grid md:grid-cols-[190px_1fr]">
                <div className="relative bg-mint p-5">
                  <span className="absolute left-4 top-4 z-10 grid size-7 place-items-center rounded-lg bg-primary text-xs font-bold text-white">
                    {index + 1}
                  </span>
                  <ExerciseIllustration
                    image={exercise.image}
                    alt={exercise.name}
                    className="mx-auto aspect-square w-full max-w-[150px]"
                  />
                </div>
                <div className="p-5 md:p-6">
                  <p className="text-[11px] font-bold uppercase tracking-wider text-green">
                    {exercise.region} · {exercise.category}
                  </p>
                  <h3 className="mt-1 text-xl font-bold text-primary">{exercise.name}</h3>
                  <ol className="mt-3 list-inside list-decimal space-y-2 text-sm leading-relaxed text-slate-600">
                    {exercise.instructions.map((line, i) => (
                      <li key={i}>{line}</li>
                    ))}
                  </ol>
                  {exercise.notes && (
                    <p className="mt-3 rounded-lg bg-mint p-3 text-sm text-primary">
                      {exercise.notes}
                    </p>
                  )}

                  <div data-prescription-fields>
                    <div className="mt-5 grid grid-cols-2 gap-4 lg:grid-cols-4">
                      <TextField
                        compact
                        label="Séries"
                        value={values.series}
                        onChange={(value) => onUpdate(exercise.id, "series", value)}
                        placeholder="Ex.: 3"
                      />
                      <TextField
                        compact
                        label="Repetições"
                        value={values.repetitions}
                        onChange={(value) => onUpdate(exercise.id, "repetitions", value)}
                        placeholder="Ex.: 10"
                      />
                      <TextField
                        compact
                        label="Tempo"
                        value={values.duration}
                        onChange={(value) => onUpdate(exercise.id, "duration", value)}
                        placeholder="Ex.: 30 s"
                      />
                      <TextField
                        compact
                        label="Frequência"
                        value={values.frequency}
                        onChange={(value) => onUpdate(exercise.id, "frequency", value)}
                        placeholder="Ex.: 1x/dia"
                      />
                    </div>
                    <label className="mt-4 block">
                      <span className="mb-2 block text-xs font-bold text-slate-600">
                        Observações individuais
                      </span>
                      <textarea
                        value={values.observation}
                        onChange={(event) =>
                          onUpdate(exercise.id, "observation", event.target.value)
                        }
                        rows={2}
                        placeholder="Orientações específicas para este exercício..."
                        className="w-full resize-none rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-3 text-sm outline-none transition focus:border-green focus:bg-white focus:ring-3 focus:ring-green/10"
                      />
                    </label>
                  </div>
                </div>
              </div>
            </article>
          );
        })}
      </div>

      <button
        type="button"
        onClick={onNewExercise}
        disabled={!canCreate}
        className="mt-5 inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-green-dark underline disabled:opacity-50"
      >
        <Plus className="size-4" />
        Adicionar exercício próprio à ficha
      </button>
      <div className="mt-8 flex flex-col items-center justify-between gap-4 rounded-2xl bg-primary p-5 text-white md:flex-row md:p-7">
        <div>
          <p className="font-bold">Tudo pronto para organizar a orientação?</p>
          <p className="mt-1 text-sm text-white/65">
            {selectedExercises.length} {selectedExercises.length === 1 ? "exercício" : "exercícios"}{" "}
            · parâmetros definidos por você
          </p>
        </div>
        <button
          type="button"
          disabled={isGenerating}
          onClick={onGenerate}
          aria-busy={isGenerating}
          className="action-primary inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-green px-6 py-3.5 text-sm font-bold text-white shadow-sm hover:bg-green-dark disabled:opacity-60 md:w-auto"
        >
          {isGenerating ? (
            <LoaderCircle
              aria-hidden="true"
              className="size-5 animate-spin motion-reduce:animate-none"
            />
          ) : (
            <FileText aria-hidden="true" className="size-5" />
          )}
          {isGenerating ? "Preparando orientação…" : "Gerar orientação em PDF"}
        </button>
      </div>
    </main>
  );
}

function PreviewView({
  pdfUrl,
  fileName,
  pdfBlob,
  selectedCount,
  notice,
  onBack,
  onDownload,
  onShare,
}: {
  pdfUrl: string;
  fileName: string;
  pdfBlob: Blob;
  selectedCount: number;
  notice: string;
  onBack: () => void;
  onDownload: () => void;
  onShare: () => void;
}) {
  return (
    <main className="container-narrow py-10 md:py-14">
      <button
        type="button"
        onClick={onBack}
        className="inline-flex items-center gap-2 text-sm font-bold text-slate-500 hover:text-primary"
      >
        <ArrowLeft className="size-4" /> Editar orientação
      </button>
      <div className="mt-8 rounded-3xl bg-primary px-6 py-8 text-white md:px-10">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-center">
          <div className="flex items-start gap-4">
            <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-green">
              <Check className="size-6" />
            </span>
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.14em] text-green-light">
                Etapa 3 de 3 · Ficha gerada
              </p>
              <h1 className="mt-2 text-2xl font-bold md:text-3xl">Sua orientação está pronta!</h1>
              <p className="mt-2 text-sm text-white/65">
                {selectedCount}{" "}
                {selectedCount === 1 ? "exercício organizado" : "exercícios organizados"} em um PDF
                profissional.
              </p>
            </div>
          </div>
          <div role="group" aria-label="Ações da ficha" className="flex flex-wrap gap-3">
            <a
              href={pdfUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-xl border border-white/20 bg-white/10 px-4 py-3 text-sm font-bold hover:bg-white/15"
            >
              <ExternalLink className="size-4" /> Abrir PDF
            </a>
            <button
              type="button"
              onClick={onDownload}
              className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-3 text-sm font-bold text-primary hover:bg-slate-50"
            >
              <Download className="size-4" /> Baixar PDF
            </button>
            <button
              type="button"
              onClick={onShare}
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#1fa855] px-4 py-3 text-sm font-bold text-white hover:bg-[#198d48]"
            >
              <Share2 className="size-4 shrink-0" /> Compartilhar ficha
            </button>
          </div>
        </div>
        <p className="mt-4 text-xs leading-relaxed text-white/75">
          Escolha WhatsApp, e-mail ou outro aplicativo no compartilhamento do aparelho. Se o
          navegador não permitir anexos, baixe o PDF e anexe-o manualmente.
        </p>
        {notice && (
          <p role="status" className="mt-3 rounded-xl bg-white/10 p-3 text-sm font-semibold">
            {notice}
          </p>
        )}
      </div>

      <div className="mt-6">
        <section className="overflow-hidden rounded-2xl border border-border bg-slate-100 shadow-soft">
          <div className="flex items-center justify-between border-b border-border bg-white px-4 py-3">
            <div className="flex items-center gap-2 text-sm font-bold text-primary">
              <FileText className="size-4 text-green" /> Pré-visualização
            </div>
            <span className="max-w-[190px] truncate text-xs text-slate-400">{fileName}</span>
          </div>
          <object
            data={pdfUrl}
            type="application/pdf"
            className="h-[680px] w-full"
            aria-label="Pré-visualização da ficha em PDF"
          >
            <div className="p-8 text-center text-sm text-slate-500">
              Seu navegador não exibe PDF nesta tela. Use “Abrir PDF” ou “Baixar PDF”.
            </div>
          </object>
        </section>

        <span className="sr-only">{pdfBlob.size} bytes</span>
      </div>
    </main>
  );
}

function TextField({
  label,
  value,
  onChange,
  placeholder,
  compact = false,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  compact?: boolean;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-xs font-bold text-slate-600">{label}</span>
      <input
        value={value}
        maxLength={150}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        className={`w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 text-sm outline-none transition focus:border-green focus:bg-white focus:ring-3 focus:ring-green/10 ${
          compact ? "h-11" : "h-12"
        }`}
      />
    </label>
  );
}
