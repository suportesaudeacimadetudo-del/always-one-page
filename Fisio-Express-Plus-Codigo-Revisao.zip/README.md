# Fisio Express Plus

Aplicação independente para utilização pelos compradores. O site público original não é alterado nem implantado por este projeto.

## Preparar e testar

Node.js 24 e Bun 1.3.1 foram utilizados. Execute `bun install --frozen-lockfile`, `bun run typecheck`, `bun run build` e `bun run test:security`.

`bun run preview:secure` inicia a aplicação com Worker de autenticação e KV locais em 127.0.0.1:5273. Cria credenciais de teste aleatórias no arquivo privado `/tmp/fisio-plus-local/credentials.json`; não as utilize na produção. Acesso por servidor estático/Vite isolado não representa a aplicação protegida e não deve ser publicado.

A suíte de navegador está em `tests/plus.browser.cjs`. Requer Playwright, Chromium e Poppler. Com a prévia segura em execução:

```
NODE_PATH=/workspace/.browser-tools/node_modules CHROMIUM_PATH=/usr/bin/chromium node --test tests/plus.browser.cjs
```

## Publicação

**Aguardar aprovação do proprietário.** Ver `docs/PUBLICACAO.md`. Endereço proposto, ainda não reservado ou publicado: `https://fisio-express-plus.pages.dev/`.

O build `dist-plus` contém um `_worker.js` e `_routes.json` que protegem todas as rotas, inclusive JavaScript, catálogo e imagens. Configurar os dois segredos e o namespace KV exclusivos do novo projeto antes de publicar. Sem configuração, o Worker retorna 503, sem liberar arquivos.

## Funcionamento

- Usuário compartilhado `admin`, senha em segredo do servidor.
- Catálogo existente: 100 exercícios, dez regiões e cem imagens originais.
- Escolha → personalização → PDF e compartilhamento real do arquivo pelo aparelho, quando disponível.
- Exercícios próprios com imagem, edição, exclusão e backup. IndexedDB `fisio-express-plus`, formato de backup `fisio-express-plus-exercises`; dados locais, sem sincronização.
- Sem preços, checkout, Pixel, anúncios, ofertas ou cadastro de assinantes.

## Limites da fase provisória

A conta é compartilhada: não há identificação individual de compradores, recuperação de senha ou controle de vencimentos/cancelamentos por assinatura. Quem obtiver as credenciais pode entrar; conteúdo e PDFs legitimamente acessados podem ser copiados. A senha pode ser trocada e a chave de sessão rotacionada para invalidar os acessos antigos. Sessões expiram em oito horas; logout revoga apenas a sessão atual. O KV tem consistência eventual: revogação e contagem de tentativas podem levar tempo para se propagar entre regiões. A limitação de tentativas é uma proteção básica, não um limitador atômico global. Não é um sistema definitivo de assinaturas.

Não há dados de pacientes no servidor de autenticação: sessões guardam apenas usuário, validade e versão de credenciais. O formulário de orientação permanece na memória da página. Exercícios próprios ficam exclusivamente no navegador/origem do Plus, mesmo após sair, até exclusão ou limpeza dos dados pelo usuário.
