const COOKIE = "__Host-fisio-plus";
const SESSION_TTL = 8 * 60 * 60;
const encoder = new TextEncoder();
const policy =
  "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self'; object-src blob:; frame-src blob:; worker-src 'self' blob:; base-uri 'none'; form-action 'self'; frame-ancestors 'none'";

function response(body, status = 200, headers = {}) {
  return new Response(body, {
    status,
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
      "X-Frame-Options": "DENY",
      "Referrer-Policy": "same-origin",
      "X-Robots-Tag": "noindex, nofollow",
      "Content-Security-Policy": policy,
      ...headers,
    },
  });
}
const redirect = (path, cookie) =>
  response(null, 303, {
    Location: path,
    ...(cookie ? { "Set-Cookie": cookie } : {}),
  });
const cookieValue = (token, maxAge = SESSION_TTL) =>
  `${COOKIE}=${token}; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=${maxAge}`;
const hex = (bytes) =>
  Array.from(new Uint8Array(bytes), (b) => b.toString(16).padStart(2, "0")).join("");
const digest = async (value) => hex(await crypto.subtle.digest("SHA-256", encoder.encode(value)));
async function sign(value, secret) {
  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  return hex(await crypto.subtle.sign("HMAC", key, encoder.encode(value)));
}
function equal(a, b) {
  if (a.length !== b.length) return false;
  let difference = 0;
  for (let i = 0; i < a.length; i++) difference |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return difference === 0;
}
async function version(env) {
  return sign(`admin\0${env.PLUS_PASSWORD}`, env.PLUS_SESSION_SECRET);
}
function readCookie(request) {
  const item = (request.headers.get("Cookie") || "")
    .split(";")
    .map((part) => part.trim())
    .find((part) => part.startsWith(COOKIE + "="));
  return item ? item.slice(COOKIE.length + 1) : "";
}
async function session(request, env) {
  const token = readCookie(request);
  if (!/^[a-f0-9]{64}\.[a-f0-9]{64}$/.test(token)) return null;
  const [id, signature] = token.split(".");
  if (!equal(signature, await sign(id, env.PLUS_SESSION_SECRET))) return null;
  const key = `session:${await digest(id)}`;
  const value = await env.PLUS_AUTH_KV.get(key, "json");
  if (!value || value.expiresAt <= Date.now() || !equal(value.version || "", await version(env)))
    return null;
  return { key };
}
function loginPage(error = "") {
  return `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Entrar | Fisio Express Plus</title><style>*{box-sizing:border-box}body{margin:0;font-family:Inter,system-ui,sans-serif;background:linear-gradient(135deg,#edf5ff,#e0f3ef);color:#103b4e;min-height:100dvh;display:grid;place-items:center;padding:20px}.card{width:100%;max-width:440px;padding:30px 24px;background:white;border:1px solid #d7e4e6;border-radius:24px;box-shadow:0 20px 60px #12344d12}.mark{display:grid;place-items:center;width:48px;height:48px;border-radius:14px;background:#0b405d;color:white;font-size:38px;font-weight:500}h1{font-size:27px;line-height:1.15;margin:20px 0 14px}p{font-size:15px;line-height:1.6;color:#526575}label{display:block;font-weight:650;font-size:14px;margin-top:18px}input{width:100%;margin-top:7px;padding:14px;border:1px solid #d7e4e6;border-radius:12px;font:inherit;background:#f8fbfc}input:focus{outline:3px solid #a6e2cf;outline-offset:1px}button{width:100%;min-height:52px;margin-top:24px;padding:14px 12px;border:0;border-radius:12px;background:#00745c;color:white;font-weight:750;font-size:14px;cursor:pointer}button:hover{background:#005d49}button:focus-visible{outline:3px solid #103b4e;outline-offset:3px}button:active{transform:scale(.99)}.error{color:#9b1c1c;background:#fff0f0;border-radius:10px;padding:12px;font-size:14px}.note{font-size:12px;margin:18px 0 0}</style></head><body><main class="card"><div class="mark" aria-hidden="true">+</div><h1>Bem-vindo ao Fisio Express Plus</h1><p>Entre para acessar sua biblioteca de exercícios e preparar suas orientações.</p>${error ? `<p class="error" role="alert">${error}</p>` : ""}<form action="/auth/login" method="post"><label>Usuário<input name="username" autocomplete="username" required maxlength="100" autocapitalize="none" spellcheck="false"></label><label>Senha<input type="password" name="password" autocomplete="current-password" required maxlength="1024"></label><button type="submit">Entrar no Fisio Express Plus</button></form><p class="note">Use os dados de acesso recebidos para utilizar o produto.</p></main></body></html>`;
}
async function formBody(request) {
  if (!request.headers.get("Content-Type")?.startsWith("application/x-www-form-urlencoded"))
    return null;
  const reader = request.body?.getReader();
  if (!reader) return null;
  let size = 0;
  const parts = [];
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    size += value.byteLength;
    if (size > 4096) {
      await reader.cancel();
      return null;
    }
    parts.push(value);
  }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const part of parts) {
    bytes.set(part, offset);
    offset += part.length;
  }
  return new URLSearchParams(new TextDecoder().decode(bytes));
}
async function handle(request, env) {
  const url = new URL(request.url);
  if (url.protocol !== "https:" && !["localhost", "127.0.0.1", "[::1]"].includes(url.hostname)) {
    url.protocol = "https:";
    return redirect(url.toString());
  }
  if (
    typeof env.PLUS_PASSWORD !== "string" ||
    env.PLUS_PASSWORD.length < 12 ||
    typeof env.PLUS_SESSION_SECRET !== "string" ||
    env.PLUS_SESSION_SECRET.length < 32 ||
    !env.PLUS_AUTH_KV ||
    !env.ASSETS
  ) {
    return response(
      "<!doctype html><html lang='pt-BR'><meta charset='utf-8'><title>Fisio Express Plus</title><h1>Acesso em preparação</h1><p>O acesso seguro ainda não foi configurado. Tente novamente mais tarde.</p></html>",
      503,
    );
  }
  if (url.pathname === "/auth/login") {
    if (request.method === "GET") {
      if (await session(request, env)) return redirect("/");
      return response(loginPage());
    }
    if (request.method !== "POST")
      return response("Método não permitido.", 405, { Allow: "GET, POST" });
    if (request.headers.get("Origin") !== url.origin) return response("Solicitação inválida.", 403);
    const form = await formBody(request);
    if (!form) return response("Formulário inválido.", 400);
    const rateKey = `rate:${await sign(url.host + ":" + (request.headers.get("CF-Connecting-IP") || "local"), env.PLUS_SESSION_SECRET)}`;
    const attempts = Number((await env.PLUS_AUTH_KV.get(rateKey)) || 0);
    if (attempts >= 10)
      return response(
        loginPage("Muitas tentativas. Aguarde alguns minutos e tente novamente."),
        429,
        { "Retry-After": "600" },
      );
    const validPassword = equal(
      await digest(form.get("password") || ""),
      await digest(env.PLUS_PASSWORD),
    );
    if (form.get("username") !== "admin" || !validPassword) {
      await env.PLUS_AUTH_KV.put(rateKey, String(attempts + 1), { expirationTtl: 600 });
      return response(loginPage("Usuário ou senha incorretos."), 401);
    }
    await env.PLUS_AUTH_KV.delete(rateKey);
    const id = hex(crypto.getRandomValues(new Uint8Array(32)));
    const token = id + "." + (await sign(id, env.PLUS_SESSION_SECRET));
    await env.PLUS_AUTH_KV.put(
      `session:${await digest(id)}`,
      JSON.stringify({
        user: "admin",
        version: await version(env),
        expiresAt: Date.now() + SESSION_TTL * 1000,
      }),
      { expirationTtl: SESSION_TTL },
    );
    return redirect("/", cookieValue(token));
  }
  if (url.pathname === "/auth/logout") {
    if (request.method !== "POST") return response("Método não permitido.", 405, { Allow: "POST" });
    if (request.headers.get("Origin") !== url.origin) return response("Solicitação inválida.", 403);
    const current = await session(request, env);
    if (current) await env.PLUS_AUTH_KV.delete(current.key);
    return redirect("/auth/login", cookieValue("", 0));
  }
  if (!["GET", "HEAD"].includes(request.method)) return response("Método não permitido.", 405);
  if (!(await session(request, env))) {
    if (url.pathname === "/" || request.headers.get("Sec-Fetch-Dest") === "document")
      return redirect("/auth/login");
    return response("Autenticação necessária.", 401, {
      "Content-Type": "text/plain; charset=utf-8",
    });
  }
  if (["/_worker.js", "/_routes.json"].includes(url.pathname))
    return response("Não encontrado.", 404);
  const asset = await env.ASSETS.fetch(request);
  const result = new Response(asset.body, asset);
  for (const [name, value] of Object.entries({
    "Cache-Control": "private, no-store",
    Vary: "Cookie",
    "Content-Security-Policy": policy,
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "same-origin",
    "X-Robots-Tag": "noindex, nofollow",
  }))
    result.headers.set(name, value);
  return result;
}
export default {
  async fetch(request, env) {
    try {
      return await handle(request, env);
    } catch {
      return response("Acesso temporariamente indisponível. Tente novamente mais tarde.", 503);
    }
  },
};
