const { test } = require("node:test");
const assert = require("node:assert/strict");
const { chromium } = require("playwright");
const { readFile, mkdir } = require("node:fs/promises");
const { execFileSync } = require("node:child_process");
const base = process.env.PLUS_TEST_URL || "http://127.0.0.1:5273";
const output = process.env.PLUS_TEST_OUTPUT || "/tmp/fisio-plus-browser";
async function browser() {
  return chromium.launch({
    executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
    args: ["--no-sandbox"],
  });
}
async function login(page) {
  const c = JSON.parse(await readFile("/tmp/fisio-plus-local/credentials.json", "utf8"));
  await page.goto(base);
  await page.getByLabel("Usuário", { exact: true }).fill(c.username);
  await page.getByLabel("Senha", { exact: true }).fill(c.password);
  await page.getByRole("button", { name: "Entrar no Fisio Express Plus" }).click();
  await page
    .getByRole("heading", { name: "Qual região do corpo você deseja trabalhar?" })
    .waitFor();
}
async function region(page, name) {
  const button = page.getByRole("button", { name, exact: true });
  if (!(await button.isVisible()))
    await page.getByRole("button", { name: "Trocar ou adicionar região" }).click();
  await button.click();
}
const noOverflow = async (page) =>
  assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));

test("servidor local real: login incorreto e proteção do catálogo/JS/100 imagens", async () => {
  await mkdir(output, { recursive: true });
  const b = await browser();
  try {
    const context = await b.newContext();
    const page = await context.newPage();
    await page.goto(base);
    await page.getByLabel("Usuário", { exact: true }).fill("admin");
    await page.getByLabel("Senha", { exact: true }).fill("senha-de-teste-incorreta");
    await page.getByRole("button", { name: "Entrar no Fisio Express Plus" }).click();
    await page.getByRole("alert").waitFor();
    assert.equal((await context.cookies()).length, 0);
    await page.evaluate(() => {
      localStorage.setItem("isPlus", "true");
      localStorage.setItem("loggedIn", "true");
    });
    await page.goto(base);
    assert.equal(
      await page.getByRole("button", { name: "Entrar no Fisio Express Plus" }).count(),
      1,
    );
    const data = await page.evaluate(async () => {
      const paths = [
        "/assets/app.js",
        "/library.json",
        "/src/data/library.json",
        ...Array.from(
          { length: 100 },
          (_, i) => `/exercises/${String(i + 1).padStart(3, "0")}.jpg`,
        ),
      ];
      return Promise.all(paths.map(async (p) => (await fetch(p)).status));
    });
    assert.ok(data.every((status) => status === 401));
  } finally {
    await b.close();
  }
});

for (const [device, width, share] of [
  ["desktop", 1440, "native"],
  ["mobile", 390, "fallback"],
])
  test(`Plus completo: catálogo, PDF, armazenamento próprio, backup e logout — ${device}`, async () => {
    await mkdir(output, { recursive: true });
    const b = await browser();
    try {
      const context = await b.newContext({
        viewport: { width, height: device === "desktop" ? 1000 : 844 },
        acceptDownloads: true,
      });
      const page = await context.newPage();
      const errors = [];
      const external = [];
      page.on("pageerror", (e) => errors.push(e.message));
      page.on("request", (r) => {
        if (/^https?:/.test(r.url()) && !r.url().startsWith(base)) external.push(r.url());
      });
      if (share === "native")
        await page.addInitScript(() => {
          Object.defineProperty(navigator, "canShare", { value: () => true });
          Object.defineProperty(navigator, "share", {
            value: async (payload) => {
              window.__shared = {
                size: payload.files[0].size,
                type: payload.files[0].type,
                signature: new TextDecoder().decode(
                  (await payload.files[0].arrayBuffer()).slice(0, 5),
                ),
              };
            },
          });
        });
      else
        await page.addInitScript(() =>
          Object.defineProperty(navigator, "canShare", { value: undefined }),
        );
      await login(page);
      await noOverflow(page);
      await page.screenshot({ path: `${output}/${device}-regions.png` });
      const cookies = await context.cookies();
      const auth = cookies.find((c) => c.name === "__Host-fisio-plus");
      assert.ok(auth?.httpOnly && auth.secure);
      assert.equal(auth.sameSite, "Strict");
      await region(page, "Todas as regiões");
      const cards = page.locator("main article");
      assert.equal(await cards.count(), 4);
      while (
        await page.getByRole("button", { name: "Ver mais exercícios", exact: true }).isVisible()
      )
        await page.getByRole("button", { name: "Ver mais exercícios", exact: true }).click();
      assert.equal(await cards.count(), 100);
      const jpeg = await page.evaluate(async () => {
        const result = [];
        for (let start = 1; start <= 100; start += 10) {
          result.push(
            ...(await Promise.all(
              Array.from({ length: Math.min(10, 101 - start) }, (_, j) => start + j).map(
                async (i) => {
                  const r = await fetch(`/exercises/${String(i).padStart(3, "0")}.jpg`);
                  const bytes = new Uint8Array(await r.arrayBuffer());
                  return {
                    status: r.status,
                    mime: r.headers.get("Content-Type"),
                    jpeg: bytes[0] === 255 && bytes[1] === 216,
                  };
                },
              ),
            )),
          );
        }
        return result;
      });
      assert.equal(jpeg.length, 100);
      assert.ok(jpeg.every((r) => r.status === 200 && r.jpeg && r.mime.includes("image/jpeg")));
      await page.getByRole("button", { name: "Buscar por nome" }).click();
      const search = page.getByLabel("Busca geral nos exercícios disponíveis");
      await search.fill("quadriceps");
      await page.getByRole("heading", { name: "Contração do quadríceps", exact: true }).waitFor();
      await search.fill("");
      await region(page, "Joelho");
      assert.equal(await cards.count(), 4);
      await cards.nth(0).getByRole("button", { name: "Adicionar à ficha" }).click();
      await cards.nth(1).getByRole("button", { name: "Adicionar à ficha" }).click();
      await region(page, "Ombro");
      await cards.nth(0).getByRole("button", { name: "Adicionar à ficha" }).click();
      if (device === "desktop") {
        await page
          .locator("main aside")
          .getByRole("button", { name: "Mover para cima" })
          .nth(1)
          .click();
        await page
          .locator("main aside")
          .getByRole("button", { name: "Mover para baixo" })
          .first()
          .click();
      }
      await page
        .getByRole("button", { name: "Continuar para personalizar", exact: true })
        .last()
        .click();
      await page.getByLabel("Nome do profissional").fill("Profissional de demonstração");
      await page.getByLabel("Identificação do paciente").fill("Paciente de teste fictício");
      await page.getByLabel("Séries", { exact: true }).first().fill("2");
      await page.getByLabel("Repetições", { exact: true }).first().fill("8");
      await page
        .getByLabel("Observações individuais")
        .first()
        .fill("Parâmetros definidos pelo profissional no teste.");
      await page.getByRole("button", { name: "Voltar à biblioteca", exact: true }).click();
      await page
        .getByRole("button", { name: "Continuar para personalizar", exact: true })
        .last()
        .click();
      assert.equal(await page.getByLabel("Séries", { exact: true }).first().inputValue(), "2");
      await noOverflow(page);
      await page.screenshot({ path: `${output}/${device}-personalize.png` });
      await page.getByRole("button", { name: "Gerar orientação em PDF", exact: true }).click();
      await page.getByRole("heading", { name: "Sua orientação está pronta!" }).waitFor();
      let pending = page.waitForEvent("download");
      await page.getByRole("button", { name: "Baixar PDF", exact: true }).click();
      const pdf = `${output}/${device}-orientacao.pdf`;
      await (await pending).saveAs(pdf);
      assert.equal((await readFile(pdf)).subarray(0, 5).toString(), "%PDF-");
      assert.match(execFileSync("pdfinfo", [pdf], { encoding: "utf8" }), /Pages:\s+1/);
      assert.match(
        execFileSync("pdftotext", [pdf, "-"], { encoding: "utf8" }),
        /Fisio Express Plus/,
      );
      if (share === "native") {
        await page.getByRole("button", { name: "Compartilhar ficha", exact: true }).click();
        assert.deepEqual(await page.evaluate(() => window.__shared.signature), "%PDF-");
        assert.equal(await page.evaluate(() => window.__shared.type), "application/pdf");
      } else {
        pending = page.waitForEvent("download");
        await page.getByRole("button", { name: "Compartilhar ficha", exact: true }).click();
        await pending;
      }
      await page.screenshot({ path: `${output}/${device}-result.png` });
      assert.doesNotMatch(
        await page.locator("body").innerText(),
        /Plano Free|Perfect Pay|R\$|Quero facilitar minhas orientações/,
      );
      assert.equal(await page.locator("footer").count(), 0);
      await noOverflow(page);
      await page.getByRole("button", { name: "Editar orientação", exact: true }).click();
      await page.getByRole("button", { name: "Voltar à biblioteca", exact: true }).click();
      await page.getByRole("button", { name: "Adicionar meu exercício", exact: true }).click();
      const dialog = page.getByRole("dialog");
      await dialog.getByLabel("Nome do exercício").fill("Exercício próprio Plus teste");
      await dialog
        .getByLabel("Como executar")
        .fill("Orientação criada pelo profissional no teste.");
      await dialog.getByLabel("Imagem opcional").setInputFiles("public/exercises/071.jpg");
      await dialog.getByAltText("Prévia da imagem do exercício").waitFor();
      await dialog.getByRole("button", { name: "Salvar exercício", exact: true }).click();
      await page.getByRole("button", { name: "Meus exercícios", exact: true }).click();
      await page
        .getByRole("heading", { name: "Exercício próprio Plus teste", exact: true })
        .waitFor();
      pending = page.waitForEvent("download");
      await page.getByRole("button", { name: "Exportar backup" }).click();
      const backup = `${output}/${device}-backup.json`;
      await (await pending).saveAs(backup);
      const json = JSON.parse(await readFile(backup, "utf8"));
      assert.equal(json.format, "fisio-express-plus-exercises");
      assert.equal(json.exercises.length, 1);
      assert.ok(json.exercises[0].image.startsWith("data:image/"));
      assert.ok(!JSON.stringify(json).includes("Paciente de teste"));
      await page.reload();
      await page.getByRole("button", { name: "Meus exercícios", exact: true }).click();
      await page
        .getByRole("heading", { name: "Exercício próprio Plus teste", exact: true })
        .waitFor();
      const databases = await page.evaluate(async () => await indexedDB.databases());
      assert.ok(databases.some((d) => d.name === "fisio-express-plus"));
      assert.ok(databases.every((d) => d.name !== "fisio-express"));
      await page
        .getByRole("button", { name: "Editar Exercício próprio Plus teste", exact: true })
        .click();
      await page
        .getByRole("dialog")
        .getByLabel("Nome do exercício")
        .fill("Exercício próprio editado");
      await page.getByRole("button", { name: "Salvar exercício", exact: true }).click();
      await page.getByRole("heading", { name: "Exercício próprio editado", exact: true }).waitFor();
      await page
        .getByRole("button", { name: "Excluir Exercício próprio editado", exact: true })
        .click();
      await page
        .getByRole("dialog")
        .getByRole("button", { name: "Excluir exercício", exact: true })
        .click();
      await page.getByRole("heading", { name: "Nenhum exercício encontrado" }).waitFor();
      await page.getByLabel("Arquivo de backup").setInputFiles(backup);
      await page
        .getByRole("heading", { name: "Exercício próprio Plus teste", exact: true })
        .waitFor();
      await page.getByRole("button", { name: "Sair", exact: true }).click();
      await page.getByRole("heading", { name: "Bem-vindo ao Fisio Express Plus" }).waitFor();
      assert.equal(
        (await context.cookies()).filter((c) => c.name === "__Host-fisio-plus").length,
        0,
      );
      await page.goto(base);
      await page.getByRole("heading", { name: "Bem-vindo ao Fisio Express Plus" }).waitFor();
      assert.deepEqual(errors, []);
      assert.deepEqual(external, []);
      await context.close();
    } finally {
      await b.close();
    }
  });

test("login em 320 px e isolamento de outro navegador", async () => {
  await mkdir(output, { recursive: true });
  const b = await browser();
  try {
    const page = await b.newPage({
      viewport: { width: 320, height: 780 },
      isMobile: true,
      hasTouch: true,
    });
    await page.goto(base);
    await noOverflow(page);
    await page.screenshot({ path: `${output}/login-320.png` });
    const button = await page
      .getByRole("button", { name: "Entrar no Fisio Express Plus" })
      .boundingBox();
    assert.ok(button.height >= 44 && button.y + button.height <= 780);
    await login(page);
    await noOverflow(page);
    await region(page, "Joelho");
    await page
      .locator("main article")
      .first()
      .getByRole("button", { name: "Adicionar à ficha" })
      .click();
    const next = await page
      .getByRole("button", { name: "Continuar para personalizar", exact: true })
      .boundingBox();
    assert.ok(next.y >= 0 && next.y + next.height <= 780);
    await noOverflow(page);
    await page.screenshot({ path: `${output}/selection-320.png` });
    await page.close();
  } finally {
    await b.close();
  }
});
