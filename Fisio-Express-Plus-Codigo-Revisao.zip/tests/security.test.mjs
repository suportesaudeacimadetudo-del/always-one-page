import { test } from "node:test";
import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import { readFile, readdir } from "node:fs/promises";
import worker from "../server/worker.mjs";
const host = "https://plus.example";
function setup() {
  const entries = new Map();
  let assetCalls = 0;
  const env = {
    PLUS_PASSWORD: randomBytes(24).toString("hex"),
    PLUS_SESSION_SECRET: randomBytes(48).toString("hex"),
    PLUS_AUTH_KV: {
      async get(key, type) {
        const v = entries.get(key);
        return v === undefined ? null : type === "json" ? JSON.parse(v) : v;
      },
      async put(key, value) {
        entries.set(key, value);
      },
      async delete(key) {
        entries.delete(key);
      },
    },
    ASSETS: {
      async fetch() {
        assetCalls++;
        return new Response("PROTECTED CATALOG");
      },
    },
  };
  const request = (path, init = {}) => worker.fetch(new Request(host + path, init), env);
  const login = (password = env.PLUS_PASSWORD, username = "admin", origin = host) =>
    request("/auth/login", {
      method: "POST",
      headers: { Origin: origin, "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ username, password }),
    });
  return { entries, env, request, login, assetCalls: () => assetCalls };
}
const cookie = (response) => response.headers.get("Set-Cookie").split(";")[0];

test("falha fechada sem configurações e não chama assets", async () => {
  const s = setup();
  delete s.env.PLUS_PASSWORD;
  for (const path of ["/", "/auth/login", "/exercises/001.jpg"])
    assert.equal((await s.request(path)).status, 503);
  assert.equal(s.assetCalls(), 0);
});
test("login visível, catálogo e imagens indisponíveis sem sessão", async () => {
  const s = setup();
  assert.match(await (await s.request("/auth/login")).text(), /Bem-vindo ao Fisio Express Plus/);
  assert.equal((await s.request("/")).headers.get("Location"), "/auth/login");
  for (const path of [
    "/assets/app.js",
    "/library.json",
    "/src/data/library.json",
    ...Array.from({ length: 100 }, (_, i) => `/exercises/${String(i + 1).padStart(3, "0")}.jpg`),
  ])
    assert.equal((await s.request(path)).status, 401);
  assert.equal(s.assetCalls(), 0);
});
test("flags locais e cookies inventados não liberam o catálogo", async () => {
  const s = setup();
  for (const value of [
    "isPlus=true",
    "__Host-fisio-plus=admin",
    "__Host-fisio-plus=" + "a".repeat(64) + "." + "b".repeat(64),
  ])
    assert.equal(
      (await s.request("/exercises/001.jpg", { headers: { Cookie: value } })).status,
      401,
    );
});
test("senha ou usuário incorretos são rejeitados sem cookie de sessão", async () => {
  const s = setup();
  for (const args of [
    ["errada", "admin"],
    [s.env.PLUS_PASSWORD, "outro"],
  ]) {
    const r = await s.login(...args);
    assert.equal(r.status, 401);
    assert.equal(r.headers.get("Set-Cookie"), null);
    assert.match(await r.text(), /Usuário ou senha incorretos/);
  }
});
test("login válido cria cookie protegido e permite assets sem cache", async () => {
  const s = setup();
  const r = await s.login();
  assert.equal(r.status, 303);
  assert.equal(r.headers.get("Location"), "/");
  const raw = r.headers.get("Set-Cookie");
  for (const part of ["Secure", "HttpOnly", "SameSite=Strict", "Path=/", "Max-Age=28800"])
    assert.ok(raw.includes(part));
  assert.ok(!raw.includes(s.env.PLUS_PASSWORD));
  const asset = await s.request("/assets/app.js", { headers: { Cookie: cookie(r) } });
  assert.equal(asset.status, 200);
  assert.equal(await asset.text(), "PROTECTED CATALOG");
  assert.match(asset.headers.get("Cache-Control"), /no-store/);
  assert.match(asset.headers.get("Content-Security-Policy"), /frame-ancestors 'none'/);
});
test("logout revoga a sessão no servidor e preserva outra sessão", async () => {
  const s = setup();
  const first = cookie(await s.login());
  const second = cookie(await s.login());
  const r = await s.request("/auth/logout", {
    method: "POST",
    headers: { Origin: host, Cookie: first },
  });
  assert.equal(r.status, 303);
  assert.match(r.headers.get("Set-Cookie"), /Max-Age=0/);
  assert.equal((await s.request("/exercises/001.jpg", { headers: { Cookie: first } })).status, 401);
  assert.equal(
    (await s.request("/exercises/001.jpg", { headers: { Cookie: second } })).status,
    200,
  );
});
test("expiração e rotação da senha/chave invalidam sessões antigas", async () => {
  for (const field of ["PLUS_PASSWORD", "PLUS_SESSION_SECRET", "expiration"]) {
    const s = setup();
    const token = cookie(await s.login());
    if (field === "expiration") {
      for (const [k, v] of s.entries) {
        if (k.startsWith("session:"))
          s.entries.set(k, JSON.stringify({ ...JSON.parse(v), expiresAt: 0 }));
      }
    } else {
      s.env[field] = randomBytes(48).toString("hex");
    }
    assert.equal((await s.request("/assets/app.js", { headers: { Cookie: token } })).status, 401);
  }
});
test("protege login/logout contra origens externas e métodos indevidos", async () => {
  const s = setup();
  assert.equal(
    (await s.login(s.env.PLUS_PASSWORD, "admin", "https://externo.example")).status,
    403,
  );
  assert.equal(
    (
      await s.request("/auth/logout", {
        method: "POST",
        headers: { Origin: "https://externo.example" },
      })
    ).status,
    403,
  );
  assert.equal((await s.request("/auth/logout")).status, 405);
  assert.equal((await s.request("/auth/login", { method: "PUT" })).status, 405);
});
test("limita tentativas de senha por origem e recusa corpos grandes", async () => {
  const s = setup();
  for (let i = 0; i < 10; i++) assert.equal((await s.login("errada")).status, 401);
  const limited = await s.login();
  assert.equal(limited.status, 429);
  assert.equal(limited.headers.get("Retry-After"), "600");
  const other = setup();
  const big = await other.request("/auth/login", {
    method: "POST",
    headers: { Origin: host, "Content-Type": "application/x-www-form-urlencoded" },
    body: "password=" + "a".repeat(5000),
  });
  assert.equal(big.status, 400);
});
test("build protege todas as rotas e não inclui comércio ou Pixel", async () => {
  const routes = JSON.parse(
    await readFile(new URL("../dist-plus/_routes.json", import.meta.url), "utf8"),
  );
  assert.deepEqual(routes, { version: 1, include: ["/*"], exclude: [] });
  const index = await readFile(new URL("../dist-plus/index.html", import.meta.url), "utf8");
  assert.doesNotMatch(index, /meta-pixel|facebook|Perfect Pay|Plano Free/);
  for (const name of await readdir(new URL("../dist-plus/assets/", import.meta.url))) {
    if (name.endsWith(".js")) {
      const text = await readFile(new URL("../dist-plus/assets/" + name, import.meta.url), "utf8");
      assert.doesNotMatch(
        text,
        /go\.perfectpay|940829541718246|Quero facilitar minhas orientações|Plano Free/,
      );
    }
  }
});
