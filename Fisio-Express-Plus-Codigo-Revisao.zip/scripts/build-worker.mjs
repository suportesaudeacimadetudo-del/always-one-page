import { copyFile, writeFile } from "node:fs/promises";
await copyFile(
  new URL("../server/worker.mjs", import.meta.url),
  new URL("../dist-plus/_worker.js", import.meta.url),
);
await writeFile(
  new URL("../dist-plus/_routes.json", import.meta.url),
  JSON.stringify({ version: 1, include: ["/*"], exclude: [] }, null, 2),
);
console.log("Worker de autenticação incluído. Todas as rotas protegidas.");
