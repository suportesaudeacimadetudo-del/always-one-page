#!/usr/bin/env bash
set -euo pipefail
# Executar somente após aprovação real do proprietário. Nunca habilitar set -x.
[[ "${1:-}" == "--approved" ]] || { echo 'Aguardar aprovação para publicar exclusivamente o Plus.'; exit 1; }
cd "$(dirname "$0")/.."
python - <<'PY'
from pathlib import Path
import tomllib,json
p=Path('wrangler.toml')
if not p.exists():raise SystemExit('Configure wrangler.toml usando o exemplo, sem senhas.')
c=tomllib.loads(p.read_text())
if c.get('name')!='fisio-express-plus' or c.get('pages_build_output_dir')!='./dist-plus':raise SystemExit('Projeto ou build incorreto. Publicação cancelada.')
kv=next((x for x in c.get('kv_namespaces',[]) if x.get('binding')=='PLUS_AUTH_KV'),{})
if len(kv.get('id',''))!=32:raise SystemExit('Configure o namespace KV exclusivo real do Plus.')
if not Path('dist-plus/_worker.js').is_file():raise SystemExit('Worker obrigatório ausente.')
r=json.loads(Path('dist-plus/_routes.json').read_text())
if r.get('include')!=['/*'] or r.get('exclude')!=[]:raise SystemExit('Todas as rotas precisam de autenticação.')
PY
: "${FISIO_PLUS_CLOUDFLARE_API_TOKEN:?Configure o token exclusivo do Plus no ambiente seguro.}"
: "${FISIO_PLUS_ACCOUNT_ID:?Configure o ID da conta do Plus.}"
export CLOUDFLARE_API_TOKEN="$FISIO_PLUS_CLOUDFLARE_API_TOKEN"
export CLOUDFLARE_ACCOUNT_ID="$FISIO_PLUS_ACCOUNT_ID"
export WRANGLER_SEND_METRICS=false
export XDG_CONFIG_HOME="${FISIO_PLUS_CONFIG_HOME:-/tmp/fisio-plus-wrangler}"
# PLUS_PASSWORD e PLUS_SESSION_SECRET devem estar configurados no projeto antes deste comando.
npx --yes wrangler@4.151.3 pages deploy dist-plus --project-name fisio-express-plus --branch main --commit-dirty=true
