import { Miniflare, convertV4MiniflareOptions } from "miniflare";
import { randomBytes } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
const root = path.resolve(new URL("..", import.meta.url).pathname);
const credentials = { username: "admin", password: randomBytes(24).toString("hex") };
const directory = "/tmp/fisio-plus-local";
await mkdir(directory, { recursive: true, mode: 0o700 });
await writeFile(path.join(directory, "credentials.json"), JSON.stringify(credentials), {
  mode: 0o600,
});
const mf = new Miniflare(
  convertV4MiniflareOptions({
    modules: true,
    scriptPath: path.join(root, "dist-plus/_worker.js"),
    compatibilityDate: "2026-07-30",
    host: "127.0.0.1",
    port: Number(process.env.PLUS_TEST_PORT || 5273),
    bindings: {
      PLUS_PASSWORD: credentials.password,
      PLUS_SESSION_SECRET: randomBytes(48).toString("hex"),
    },
    kvNamespaces: ["PLUS_AUTH_KV"],
    assets: {
      directory: path.join(root, "dist-plus"),
      binding: "ASSETS",
      run_worker_first: true,
      routerConfig: { has_user_worker: true },
    },
  }),
);
console.log("Prévia local autenticada:", (await mf.ready).toString());
console.log(
  "Credenciais temporárias gravadas no arquivo privado /tmp/fisio-plus-local/credentials.json. Não usar em produção.",
);
for (const signal of ["SIGTERM", "SIGINT"])
  process.on(signal, async () => {
    await mf.dispose();
    process.exit(0);
  });
